<?php 
session_start();
if(isset($_SESSION['admin']))
{
if($_SESSION['admin'] != 'admin'){
header("location:error.php");
}
}else {
header("location:../error.php");
}
include ('db.php');
?>
<html>
<head>
	<title>adminDashBoard</title>
	<link href="login.css" type="text/css" rel="stylesheet" />
</head>
<header id="banner" >
<h2 class="h2">CHILDREN PARTY 4 U</h2>
<img src="img/logo.jpg" height="100" width="200" />

<ul>
	<li><a style="color:white" href="display.php" >Display</a></li> |
	<li><a style="color:white" href="bookedDate.php" >Show booked party</a></li>  |
	<li><a style="color:white" href="../logout.php" >Logout</a></li>
</ul>
</header>
<body onload = "startTime()" style ="text-align:center" >

<h2>welcome <?php echo $_SESSION['first_name']; ?></h2>


Time: <div id="txt"></div>
<br /><br />
<script>
function startTime(){
	var today = new Date();
	var h = today.getHours();
	var m = today.getMinutes();
	var s = today.getSeconds();
	
	m = checkTime(m);
	s = checkTime(s);
	document.getElementById('txt').innerHTML = h + ":" + m + ":" + s;
	var t = setTimeout(startTime, 500);

}

function checkTime(i) {
	if (i < 10) {i = "0" + i};
	return i;
}

function validateform() {
var x = document.forms["myform"]["t1"].value;
var y = document.forms["myform"]["t2"].value;
var z = document.forms["myform"]["t3"].value;
var a = document.forms["myform"]["t4"].value;
var b = document.forms["myform"]["t5"].value;
var c = document.forms["myform"]["t6"].value;

if (x == "" || y == "" || z == "" || a == "" || b == "" || c == "") {
	alert("All fields must be filled out");
	return false;
	}
}


</script>

<form name="myform" onsubmit="return validateform()" method='post' action='insertParty.php' enctype='multipart/form-data'>
	<table>
		<tr>
			<td>Type OF Party</td>
			<td><input type="text" name="t1" required ></td>
		</tr>
		<tr>
			<td>Discription</td>
			<td><input type="text" name="t2"></td>
		</tr>
		<tr>
			<td>cost</td>
			<td><input type="text" name="t3" required pattern= "^[0-9]+"></td>
		</tr>
		<tr>
			<td>length of Time</td>
			<td><input type="text" name="t4" max="30" required pattern= "^[0-9]+"></td>
		</tr>
		<tr>
			<td>no of children</td>
			<td><input type="text" name="t5" required pattern= "^[0-9]+"></td>
		 
		</tr>
		<tr>
			<td>product/services</td>
			<td><input type="text" name="t6"></td>
		</tr>
		<tr>
			<td>image</td>
			<td><input type="file" name="img"></td>
		</tr>
			


	</table>
<br /><br />
<input type="submit" value="insert" name="submit1" />

</form>

</body>
<footer id="foot">
All pages and content CopyRight@ 2017-2018 Vivek Thapa
Privacy policies
</footer>
</html>