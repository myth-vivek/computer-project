<?php
	include 'db.php';
if(isset($_POST['submit1']))
{
$target = "img/".basename($_FILES['img']['name']);

$name = $_POST['t1'];
$disc = $_POST['t2'];
$cost = $_POST['t3'];
$length = $_POST['t4'];
$noofchild = $_POST['t5'];
$services = $_POST['t6'];

$file_name = $_FILES['img']['name']; //name of the file_name
$file_size = $_FILES['img']['size']; //size of the file
$ext = pathinfo($file_name,PATHINFO_EXTENSION); // extension of the file 
$currrent_insert_id = $connect->insert_id;

$new_file_name = "party_".$currrent_insert_id."_pic.".$ext;

if($ext =='jpg' || $ext =='png' || $ext =='gif' || $ext =='JPG' || $ext =='PNG' || $ext =='GIF')
{
	move_uploaded_file($_FILES['img']['tmp_name'],$target);
}

else {
	echo "invaid file format" ;
	die();
}


	$sql1 = "INSERT INTO `table` (`id`, `typeofparty`, `discription`, `cost`, `length`, `noofchild`, `services`,`img`)"
	."VALUES (NULL, '$name', '$disc', '$cost', '$length', '$noofchild', '$services','$file_name')";
			
	$result = $connect->query($sql1);
	if($result) {
	echo "data inserted";
	} else {
	 echo "operation failed: ".$connect->error;
	}

	}

?>
</br>
<strong><a href="admindashboard.php" title="click to return" >Click here to return</a></strong>
<?php
if ($_FILES)
{
$name = $_FILES['img']['name'];

switch($_FILES['img']['type'])
{
case 'image/jpeg': $ext = 'jpg'; break;
case 'image/gif': $ext = 'gif'; break;
case 'image/png': $ext = 'png'; break;
case 'image/tiff': $ext = 'tif'; break;
default: $ext = ''; break;
}
if($ext == ''){
echo "sorry, extinsion of img didnt match";
return false;
}

}
?>