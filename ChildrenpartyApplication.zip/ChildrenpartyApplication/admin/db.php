<?php
/* Database connection settings */
define('A','localhost'); 
define('B','root');
define('C','');
define('D','accounts');

$connect = new mysqli(A,B,C,D) or die($mysqli->error);
?>