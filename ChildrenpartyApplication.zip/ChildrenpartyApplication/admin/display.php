
<?php 
include('db.php');


	$query = "SELECT * FROM `table`";
	$result = $connect->query($query);
	$data = $result->fetch_array();
	
	echo "<table border==1>";
	echo "<tr>";
	echo "<th>"; echo "type of party"; echo "</th>";
	echo "<th>"; echo "discription"; echo "</th>";
	echo "<th>"; echo "cost per child"; echo "</th>";
	echo "<th>"; echo "length of time"; echo "</th>";
	echo "<th>"; echo "noofchild"; echo "</th>";
	echo "<th>"; echo "services"; echo "</th>";
	echo "<th>"; echo "img"; echo "</th>";
	echo "<th>"; echo "update"; echo "</th>";
	echo "<th>"; echo "Delete"; echo "</th>";

	echo "</tr>";
	
	while($data = $result->fetch_array()) {
	echo "<tr>";
	echo "<td>"; echo $data['typeofparty']; echo "</td>"; 
	echo "<td>"; echo $data['discription']; echo "</td>";
	echo "<td>"; echo $data['cost']; echo "</td>";
	echo "<td>"; echo $data['length']; echo "</td>";
	echo "<td>"; echo $data['noofchild']; echo "</td>";
	echo "<td>"; echo $data['services']; echo "</td>";
	echo "<td>"; echo "<img width='200' src='img/".$data['img']."'>";
	?>
	
	<td><a href="update.php?id=<?php echo $data['id'];?>">UPDATE</a></td>
	<td><a href="delete.php?id=<?php echo $data['id'];?>">DELETE</a></td>

	<?php
	echo "</tr>";
	}
	echo "</table>";
	
?>
<a href="admindashboard.php" >Home</a>