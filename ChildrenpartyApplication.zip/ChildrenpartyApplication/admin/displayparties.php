<?php
$conn = new mysqli('localhost', 'root', '', 'accounts');
$select_query = "SELECT * FROM `table`";
$result = $conn->query($select_query);
while($data = $result->fetch_assoc()){
	echo "<div>".$data['typeofparty']."---";
	echo $data['cost']."----";
	echo "</div>";
	?>
	<img src="<?php echo $data['img']; ?>" width="200" />
	<?php	
	}
?>

