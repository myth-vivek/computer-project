<body bgcolor="grey" >
<h1>User details with already booked date</h1>
<?php
include('db.php');


	$query = "SELECT * FROM `book_party`";
	$result = $connect->query($query);
	$data = $result->fetch_array();
	
	echo "<table border==1>";
	echo "<tr>";
	echo "<th>"; echo "type of party"; echo "</th>";
	echo "<th>"; echo "username"; echo "</th>";
	echo "<th>"; echo "no of child"; echo "</th>";
	echo "<th>"; echo "cost"; echo "</th>";
	echo "<th>"; echo "discription"; echo "</th>";
	echo "<th>"; echo "booked date"; echo "</th>";
	echo "</tr>";
	
	while($data = $result->fetch_array()) {
	echo "<tr>";
	echo "<td>"; echo $data['typeofparty']; echo "</td>"; 
	echo "<td>"; echo $data['username']; echo "</td>";
	echo "<td>"; echo $data['noofchild']; echo "</td>";
	echo "<td>"; echo $data['cost']; echo "</td>";
	echo "<td>"; echo $data['discription']; echo "</td>";
	echo "<td>"; echo $data['booked date']; echo "</td>";
	echo "</tr>";
	}
	echo "</table>";
	?>
</body>