<h1>Update</h1>
<?php
require_once("db.php");
$id = $_GET['id']; //2
$query = "SELECT * FROM `table` WHERE id = '$id'";
$result = $connect->query($query) or trigger_error($connect->error."[$query]");
$data = $result->fetch_array();
?>

<form method='post' action='update_action.php' enctype='multipart/form-data'>
	<table>
		<tr>
			<td>Enter Name</td>
			<td><input type="text" name="t1" value="<?php echo $data['typeofparty']; ?>"></td>
		</tr>
		<tr>
			<td>Discription</td>
			<td><input type="text" name="t2" value="<?php echo $data['discription']; ?>"></td>
		</tr>
		<tr>
			<td>cost</td>
			<td><input type="text" name="t3" value="<?php echo $data['cost']; ?>"></td>
		</tr>
		<tr>
			<td>length</td>
			<td><input type="text" name="t4" value="<?php echo $data['length']; ?>"></td>
		</tr>
		<tr>
			<td>no of children</td>
			<td><input type="text" name="t5" value="<?php echo $data['noofchild']; ?>"></td>
		</tr>
		<tr>
			<td>product/services</td>
			<td><input type="text" name="t6" value="<?php echo $data['services']; ?>"></td>
		</tr>
		<tr>
			<td>image</td>
			<td><input type="file" name="img"></td>
		</tr>
		<p><input type="hidden" name="id" value="<?php echo $data['id'] ?>" /></p>

			


	</table>

<p><input type="submit" value="submit" /> 
<a href = "admindashboard.php" ><input type="submit" value="Back" /></a></p>
</form>

<a href="logout.php" >Log out</a>