<html>
<head>
</head>
<?php
require_once("db.php");


	
	$id = $_GET['id'];
	
	$query1 = "DELETE FROM `accounts`.`table` WHERE `table`.`id` = '$id'";
	
	$result = $connect->query($query1);
	
	header("location:display.php");


?>
</html>