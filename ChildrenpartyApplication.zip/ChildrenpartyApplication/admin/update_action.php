<?php
include("db.php");
$name = $_POST['t1'];
$disc = $_POST['t2'];
$cost = $_POST['t3'];
$length = $_POST['t4'];
$noofchild = $_POST['t5'];
$services = $_POST['t6'];


$id = $_POST['id'];
if ($_FILES) {
$target = "img/".basename($_FILES['img']['name']);
$file_name = $_FILES['img']['name']; //name of the file_name
$file_size = $_FILES['img']['size']; //size of the file
$ext = pathinfo($file_name,PATHINFO_EXTENSION); // extension of the file 

$new_file_name = "hamro_apps_".$id."_pic.".$ext;

if($ext =='jpg' || $ext =='png' || $ext =='gif' || $ext =='JPG' || $ext =='PNG' || $ext =='GIF' || $ext == 'jpeg')
{
	move_uploaded_file($_FILES['img']['tmp_name'], $target);
}

else {
	echo "invaid file format" ;
	die();
}
}


$q = "update `table` set typeofparty='$name', discription='$disc', cost = '$cost', length = '$length',noofchild = '$noofchild',services = '$services',img = '$file_name' where id='$id'";
$result = $connect->query($q) or trigger_error($connect->error."[$q]");

header("location:display.php");
 ?>