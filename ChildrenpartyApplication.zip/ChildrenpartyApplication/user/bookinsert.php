<?php
/*function currconvert($amount, $from, $to)
{
	$url = "http://www.google.com/finance/converter?a=$amount&from=$from&to=$to";
	$data = file_get_contents($url);
	preg_match("/<span class=bld>(.*)<\/span>/" ,$data, $converted);
	$converted = preg_replace("/[^0-9.]/", "", $converted[1]);
    return round($converted, 3);
}
If(isset($_POST['cost'])){
  # Call function 
$price = $_POST['cost']; 
if(isset($_POST['curr']))
{
 $to_curr = $_POST['curr'];
  echo currconvert($price, "GBP", $to_curr); // USD
 }
 else
 {
 echo $price;
 }
}*/


?>
<?php
	$con = new mysqli("localhost","root","","accounts");

If(isset($_POST['submit'])){

	$year = $_POST['y'];
	$month = $_POST['m'];
	$day = $_POST['d'];

$format_date = $year."-".$month."-".$day ;
$noOfChildren = $_POST['noOfChildren'];
$typeofparty = $_POST['typeofparty'];
$description = $_POST['description'];
$Username = $_POST['username'];
$cost = $_POST['cost'];

$query = "select * from `table` where typeofparty = '$typeofparty'";
$result = $con->query($query);
while($data =$result->fetch_array()){
	if($data['noofchild'] < $noOfChildren){
	
		echo "invalid numberof children. Enter less than ".$data['noofchild']."<br />";
	    die();
	}
}

$query1="select * from `book_party`";
$result1 = $con->query($query1);
while($data1 = $result1->fetch_array()) {
   if($data1['booked date'] == $format_date){
   		echo "this date is already booked. Please try another ";
   		die();
   }
   }


	$query ="select * from `users`";
	$result = $con->query($query);
	while($data =$result->fetch_array()){
	if($data['first_name'] == $Username) {
		
		$query1 = "insert into book_party values(null,'$typeofparty','$Username','$noOfChildren','$cost','$description','$format_date')";
		$result1 = $con->query($query1);
		echo "data inserted";
		return true;
	} else {
		echo"invalid name";
		die();
	}
	}


}
?>