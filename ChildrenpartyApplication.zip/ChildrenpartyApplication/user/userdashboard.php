<html>
	<head>
		<title>your dashboard</title>
		<script type="text/javascript" src="engine.js"> </script>
		<link href="login.css" type="text/css" rel="stylesheet" />
	</head>

<?php session_start(); ?>
<?php

if(!isset($_SESSION['user'])) {
header("location:../error.php");
}
?>
<h2 id="heading">welcome <?php echo $_SESSION['first_name'].". This is your Dashboard" ?></h2>
<header id="banner" >
<h2>CHILDREN PARTY 4 YOU</h2>
<img src="img/logo.jpg" height="100" width="100" />
<ul>
	<li><a style="color:white" href="#" >view party</a></li> |
	<li><a style="color:white" href="book_party.php" >book party</a></li>  |
	<li><a style="color:white" href="about.php" >About us</a></li> |
	<li><a style="color:white" href="#" >contact</a></li>  |
	<li><a style="color:white" href="../logout.php" >Logout</a></li>
</ul>
</header>
<script>
function startTime(){
	var today = new Date();
	var h = today.getHours();
	var m = today.getMinutes();
	var s = today.getSeconds();
	
	m = checkTime(m);
	s = checkTime(s);
	document.getElementById('txt').innerHTML = h + ":" + m + ":" + s;
	var t = setTimeout(startTime, 500);

}

function checkTime(i) {
	if (i < 10) {i = "0" + i};
	return i;
}
</script>
</br /><br />
<p>Time :<span id="txt"></span></p>
<body onload = "startTime()" style = "text-align:center">

<br /> <br />
<form id="frm" method="get" action="" >
<input type="submit" name="view" value="view"/>
<input type="submit" name="date" value="view avilable dates"/>
</form>

<?php
if(isset($_GET['view'])) {

$connect = new mysqli('localhost','root','','accounts');
if(!$connect) die($connect->error);

$query = "SELECT * FROM `table`";
	$result = $connect->query($query);
	if($result) {
	echo "List of parties";
	
	} else {
	echo "ERROR :".$connect->error;
	}
	echo "<table border==1>";
	echo "<tr>";
	echo "<th>"; echo "type of party"; echo "</th>";
	echo "<th>"; echo "discription"; echo "</th>";
	echo "<th>"; echo "cost per child"; echo "</th>";
	echo "<th>"; echo "length of time"; echo "</th>";
	echo "<th>"; echo "no of child"; echo "</th>";
	echo "<th>"; echo "services"; echo "</th>";
	echo "<th>"; echo "img"; echo "</th>";
	echo "</tr>";
	
	
	$data = $result->fetch_array();

	while($data = $result->fetch_array()) {
	echo "<tr>";
	echo "<td>"; echo $data['typeofparty']; echo "</td>";
	echo "<td>"; echo $data['discription']; echo "</td>";
	echo "<td>"; echo $data['cost']; echo "</td>";
	echo "<td>"; echo $data['length']; echo "</td>";
	echo "<td>"; echo $data['noofchild']; echo "</td>";
	echo "<td>"; echo $data['services']; echo "</td>";
	echo "<td>"; echo "<img width='200' src='img/".$data['img']."' >";
	?>
	<?php
	echo "</tr>";
	}
	echo "</table>";
	}
	
if(isset($_GET['date'])) {

echo "date pending";

}


?>

</br /><br />
<footer id="foot">
<ul>All pages and content CopyRight@ 2017-2018 Vivek Thapa
Privacy policies
</ul>
</footer>
</body>
</html>