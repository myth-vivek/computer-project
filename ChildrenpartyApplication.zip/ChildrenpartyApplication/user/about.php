<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset=UTF-8>
		<title>About us</title>
		<link href="login.css" type="text/css" rel="stylesheet" />
	</head>
	
	<header id="banner" >
<h2>CHILDREN PARTY 4 YOU</h2>
<img src="img/logo.jpg" height="100" width="100" />
<ul>
	<li><a style="color:white" href="about.php" >About us</a></li> |
	<li><a style="color:white"href="book_party.php" >booking</a></li>  |
	<li><a style="color:white" href="#" >contact</a></li>  |
	<li><a style="color:white" href="../logout.php" >Logout</a></li>
</ul>
</header>
	<body style="text-align:center">
	<title>About</title>	
<br>
</br>
	<h1>Location</h1>
	<p>Located in Thamel, this venue is within a 10-minute walk of Temples of the Elements, Three Goddesses Temples, and Garden of Dreams. Kathesimbhu Stupa and Nara Devi Temple are also within 15 minutes.</p>
<br/>

<h2> Contact </h2>
<p> <address > 12 Sea View, thamel, nepal</address> </p>
<p> <a href=”http://maps.google.com/maps?q=newquay” > Find us on Google
Maps </a> </p>
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14136.957469810657!2d85.2959632232562!3d27.64806498268238!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39eb178514f97739%3A0xeb1f6e5c822e62ab!2sBhaisepati%2C+Karyabinayak%2C+Nepal!5e0!3m2!1sen!2s!4v1479013484758" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
<p> <a href="Mailto:vivekmgr29@gmail.org?subject=XHTML & cc=sales@example.org" target="_blank">Email us</a></p> 
	
	</body>
	<footer id="foot">
	All pages and content CopyRight@ 2017-2018 Vivek Thapa
Privacy policies
</footer>
</html>
