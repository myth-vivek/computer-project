<head>
	<title>book party</title>
	<link href="login.css" type="text/css" rel="stylesheet" />
</head>
<header id="banner" >
<h2>CHILDREN PARTY 4 YOU</h2>
<img src="img/logo.jpg" height="100" width="100" />
<ul>
	<li><a style="color:white" href="about.php" >About us</a></li> |
	<li><a style="color:white" href="book_party.php" >booking</a></li>  |
	<li><a style="color:white" href="about.php" >contact</a></li>  |
	<li><a style="color:white" href="../logout.php" >Logout</a></li>
</ul>
</header>
<body style = "text-align:center" >
<br />
<div class="div">
<fieldset>
<legend>party booking</legend>
<form method = "POST" action="bookinsert.php" onsubmit="myFunction()">
<p>Year
<select name ="y">
<option>2017</option>
<option>2018</option>
<option>2019</option>
<option>2020</option>
</select>
Month
<select name ="m">
<option value = "01">Jan</option>
<option value = "02">Feb</option>
<option value = "03">March</option>
<option value = "04">April</option>
<option value = "05">May</option>
<option value = "06">June</option>
<option value = "07" >July</option>
<option value = "08">August</option>
<option value = "09">September</option>
<option value = "10">October</option>
<option value = "11">November</option>
<option value = "12">December</option>
</select>
Day 
<select name ="d">
<option value = "01">01</option>
<option value = "02">02</option>
<option value = "03">03</option>
<option value = "04">04</option>
<option value = "05">05</option>
<option value = "06">06</option>
<option value = "07">07</option>
<option value = "08">08</option>
<option value = "09">09</option>
<option value = "10">10</option>
<option value = "11">11</option>
<option value = "12">12</option>
<option value = "13">13</option>
<option value = "14">14</option>
<option value = "15">15</option>
<option value = "16">16</option>
<option value = "17">17</option>
<option value = "18">18</option>
<option value = "19">19</option>
<option value = "20">20</option>
<option value = "21">21</option>
<option value = "22">22</option>
<option value = "23">23</option>
<option value = "24">24</option>
<option value = "25">25</option>
<option value = "26">26</option>
<option value = "27">27</option>
<option value = "28">28</option>
<option value = "29">29</option>
<option value = "30">30</option>

</select></p>

<p>Username <input type = "text" name ="username" required/></p>
<p>Number of Children<input type ="number" min="10" max="<?php $noOfChildren ?>" name = "noOfChildren" id = "no" required/></p>

<P>Type of Party
<?php
include('../db.php');
    $query1 = "SELECT * FROM `table`";
    $result1 = $connect->query($query1);
	?><select id="typeofparty" name="typeofparty" onchange="checkcost()"><?php
    while($row = $result1->fetch_array()){                                                 
       echo "<option value='".$row['typeofparty']."'>".$row['typeofparty']."</option>";
    }
	?></select></p>
	
<script type="text/javascript">
	function checkcost(){
	var x = document.getElementById("typeofparty").value;
	if(x == "hana"){
	document.getElementById("cost").value = "4000";
	}else if(x == "birthday party"){
		document.getElementById("cost").value = "8000";
	}else{
		document.getElementById("cost").value = "2000";
	}
	}
</script>

<p>Cost<input type ="text" name = "cost" id="cost" value="8000" required/></p>
<span id="con" ></span>
<p>Description <input type = "text" name = "description" required/> </p>
<p>Currency <select id="curr" name="curr" onchange="currency()">
				<option value="GBP" >POUND</option>
				<option value="USD" >AMERICAN DOLLER</option>
				<option value="ERO" >EURO</option>
			</select>
			
<script type="text/javascript">
function currency(){
	var y = document.getElementById("curr").value;
	if(y == "GBP"){
	document.getElementById("con").innerHTML = "POUND";
	document.getElementById("cost").value = "450.46";
	}else if(y == "USD"){
	document.getElementById("con").innerHTML = "AMERICAN DOLLER";
	document.getElementById("cost").value = "500.68";
	}else{
	document.getElementById("con").innerHTML = "EURO";
	document.getElementById("cost").value = "419.05";
	}
	}
</script>
<p><input type="submit" name ="submit" value ="submit"/></p>
</form>
<fieldset>
</div>
</body><br />
 <a href="userdashboard.php">back</a>

<footer id="foot">
All pages and content CopyRight@ 2017-2018 Vivek Thapa
Privacy policies
</footer>
</html>
