<?php 
/* Main page with two forms: sign up and log in */
require 'db.php';
session_start();

if(!isset($_SESSION['count'])){
$_SESSION['count'] = 0;
}


?>


<!DOCTYPE html>
<html>
<head>
  <title>Sign-Up/Login Form</title>
  <?php include 'css/css.html'; ?>
</head>

<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['login'])) { //user logging in
		
	
        require 'login.php';
        
    }
    
    elseif (isset($_POST['register'])) { //user registering
        
        require 'register.php';
        
    }
}
?>

<img src="img/party2.jpeg" 	height="150" width="200">
<img src="img/party4.jpg" 	height="150" width="500">
<img src="img/partyall.jpg" height="150" width="400">
<img src="img/party2.jpeg" 	height="150" width="200">

<br/>
<body>

  <div class="form">
      
      <ul class="tab-group">
        <li class="tab"><a href="#signup">Sign Up</a></li>
        <li class="tab active"><a href="#login">Log In</a></li>
      </ul>
      
      <div class="tab-content">

         <div id="login">   
          <h1>Welcome Back!</h1>
          
          <form action="index.php" method="post" autocomplete="off">
          
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email" required autocomplete="off" name="email"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password" required autocomplete="off" name="password"/>
          </div>
          
          <p class="forgot"><a href="forgot.php">Forgot Password?</a></p>
          
          <button class="button button-block" id="login" name= "login" onclick="check(<?php echo $_SESSION['count']; ?>)">Log In</button>
          
          </form>

        </div>
          
        <div id="signup">   
          <h1>Sign Up for Free</h1>
          
          <form action="index.php" method="post" autocomplete="off">
          
          <div class="top-row">
            <div class="field-wrap">
              <label>
                First Name<span class="req">*</span>
              </label>
              <input type="text" required autocomplete="off" name='firstname' />
            </div>
        
            <div class="field-wrap">
              <label>
                Last Name<span class="req">*</span>
              </label>
              <input type="text"required autocomplete="off" name='lastname' />
            </div>
          </div>
		  
		    <div class="field-wrap">
              <label>
                Age<span class="req">*</span>
              </label>
              <input type="text"required autocomplete="off" name='age' pattern= "^[0-9]+" />
            </div>


          <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email"required autocomplete="off" name='email' />
          </div>
		  
          
          <div class="field-wrap">
            <label>
              Set A Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name='password' title="make use of different characters"/>
          </div>
		  
		  <div class="field-wrap">
           
           <select name="gender">
		   <option value="" disabled>Select your gender</option>
            <option value="male" selected>Male</option>
            <option value="female">Female</option>
            </select>
            </div>
          
          <button type="submit" class="button button-block" name="register" onclick="check2()" >Register</button>
          
          </form>

        </div>  
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->

<script>
function check2(){

var gender = document.getElementById('gender').value;
if (gender == "") {
alert("Enter remaining fields");
return false;
die();
}
return true;
}
</script>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
