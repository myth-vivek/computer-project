<?php
/* User login process, checks if user exists and password is correct */
SESSION_START(); //session started
// Escape email to protect against SQL injections
$email = $connect->escape_string($_POST['email']);
$result = $connect->query("SELECT * FROM users WHERE email='$email'");


if ( $result->num_rows == 0 ){ // if there is no row than.User doesn't exist
    $_SESSION['message'] = "User with that email doesn't exist!";
	if (!isset($_SESSION['count'])){ $_SESSION['count'] = 0;}
	else ++$_SESSION['count'];
    header("location: error.php");
}
else { // User exists
    $user = $result->fetch_assoc();

		$user_type =$user['user_type'];
        
        $_SESSION['email'] = $user['email'];
        $_SESSION['first_name'] = $user['first_name'];
        $_SESSION['last_name'] = $user['last_name'];
        $_SESSION['active'] = $user['active'];
        
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = true;
		
		
if(($_POST['password'] == $user['password'])){
//session
	if($user_type =='admin')
	{
	$_SESSION['admin'] = 'admin';
	header('location:admin/admindashboard.php');
	}
	else {
	//normal
	$_SESSION['user'] = 'user';
	header('location:user/userdashboard.php');
	    }
				
    }
		else {
			$_SESSION['message'] = "operation failed, try again!";
			header("location: error.php");
		}


    }
?>